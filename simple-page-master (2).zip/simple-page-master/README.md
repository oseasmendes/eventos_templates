# simple-page
This page created for cakephp version 4 tutorial, which has given in youtube. 

Youtube video link : https://www.youtube.com/watch?v=OSCeRgMFcNg&feature=youtu.be

<img src = "https://github.com/pitocms/simple-page/blob/master/Screenshot_2020-01-25%20Hello%2C%20world%20.png">
